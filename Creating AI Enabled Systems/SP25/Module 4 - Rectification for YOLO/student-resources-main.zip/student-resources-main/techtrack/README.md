
[comment]: <> (Task 6: Include instructions to run the service)